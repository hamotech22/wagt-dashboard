import LocationOnIcon from "@mui/icons-material/LocationOn";

export default function LocationsMap() {
  return (
    <div className="h-full w-full rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-4 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-100 text-red-500">
          <LocationOnIcon />
        </div>

        <div>
          <h2 className="font-bold text-slate-800">المواقع والبوابات</h2>

          <p className="text-sm text-slate-400">توزيع المواقع</p>
        </div>
      </div>

      <div className="flex h-48 items-center justify-center rounded-lg bg-slate-100">
        <div className="text-center">
          <LocationOnIcon sx={{ fontSize: 50 }} className="text-red-500" />

          <p className="mt-2 text-sm text-slate-500">الخريطة ستظهر هنا</p>
        </div>
      </div>
    </div>
  );
}
