const mockMunicipalities = [
  { id: 1, name: 'المدينة الوسطى' },
  { id: 2, name: 'المدينة الشمالية' },
  { id: 3, name: 'المدينة الجنوبية' },
];

const mockContractors = [
  { id: 1, name: 'مقاول الخليج' },
  { id: 2, name: 'مقاول النخيل' },
  { id: 3, name: 'مقاول الرواد' },
];

const mockProjects = [
  {
    id: 1,
    name: 'مشروع النخيل',
    code: 'PRJ-1001',
    contractNumber: 'CT-101',
    municipalityId: 1,
    contractorId: 1,
    status: 'active',
    startDate: '2024-01-10',
    budget: 2500000,
  },
  {
    id: 2,
    name: 'مشروع الروضة',
    code: 'PRJ-1002',
    contractNumber: 'CT-202',
    municipalityId: 2,
    contractorId: 2,
    status: 'pending',
    startDate: '2024-02-12',
    budget: 1800000,
  },
  {
    id: 3,
    name: 'مشروع السد',
    code: 'PRJ-1003',
    contractNumber: 'CT-303',
    municipalityId: 3,
    contractorId: 3,
    status: 'completed',
    startDate: '2023-09-03',
    budget: 4200000,
  },
  {
    id: 4,
    name: 'مشروع الأفق',
    code: 'PRJ-1004',
    contractNumber: 'CT-404',
    municipalityId: 1,
    contractorId: 2,
    status: 'active',
    startDate: '2024-04-01',
    budget: 3200000,
  },
];

const mockSites = [
  { id: 101, projectId: 1, name: 'موقع النخيل 1', finalDestinationCode: 'FD-001', active: true },
  { id: 102, projectId: 1, name: 'موقع النخيل 2', finalDestinationCode: 'FD-002', active: true },
  { id: 201, projectId: 2, name: 'موقع الروضة', finalDestinationCode: 'FD-011', active: false },
  { id: 301, projectId: 3, name: 'موقع السد', finalDestinationCode: 'FD-021', active: true },
];

const mockTransactions = [
  { id: 1001, projectId: 1, plate: '1234', wasteType: 'خلفيات', weight: 12.4, time: '2024-06-10 08:30', syncStatus: 'synced' },
  { id: 1002, projectId: 1, plate: '5678', wasteType: 'بناء', weight: 8.1, time: '2024-06-11 09:00', syncStatus: 'pending' },
  { id: 1003, projectId: 2, plate: '9012', wasteType: 'أخشاب', weight: 5.5, time: '2024-06-12 11:15', syncStatus: 'failed' },
  { id: 1004, projectId: 3, plate: '3456', wasteType: 'طين', weight: 15.2, time: '2024-06-13 13:45', syncStatus: 'synced' },
];

export const statuses = {
  all: { label: 'الكل', style: 'bg-slate-100 text-slate-700' },
  active: { label: 'نشط', style: 'bg-emerald-100 text-emerald-700' },
  pending: { label: 'قيد التنفيذ', style: 'bg-amber-100 text-amber-700' },
  completed: { label: 'مكتمل', style: 'bg-sky-100 text-sky-700' },
  cancelled: { label: 'ملغي', style: 'bg-red-100 text-red-700' },
};

export const syncStatuses = {
  synced: { label: 'تم الإرسال', style: 'bg-emerald-100 text-emerald-700' },
  pending: { label: 'قيد الانتظار', style: 'bg-amber-100 text-amber-700' },
  failed: { label: 'فشل', style: 'bg-red-100 text-red-700' },
};

export const projectsApi = {
  async list() {
    return mockProjects;
  },

  async get(id) {
    const projectId = Number(id);
    const project = mockProjects.find((item) => item.id === projectId);
    if (!project) throw new Error('المشروع غير موجود');
    return project;
  },

  async sites(projectId) {
    return mockSites.filter((site) => site.projectId === Number(projectId));
  },

  async transactions(projectId) {
    return mockTransactions.filter((item) => item.projectId === Number(projectId));
  },

  async lookups() {
    return {
      municipalities: mockMunicipalities,
      contractors: mockContractors,
    };
  },

  async create(data) {
    const created = {
      ...data,
      id: Date.now(),
      code: data.code || `PRJ-${Date.now()}`,
    };
    mockProjects.unshift(created);
    return created;
  },

  async update(id, data) {
    const index = mockProjects.findIndex((item) => item.id === id);
    if (index === -1) throw new Error('المشروع غير موجود');
    const updated = { ...mockProjects[index], ...data, id };
    mockProjects[index] = updated;
    return updated;
  },

  async remove(id) {
    const index = mockProjects.findIndex((item) => item.id === id);
    if (index === -1) throw new Error('المشروع غير موجود');
    mockProjects.splice(index, 1);
    return { id };
  },
};
