// ⚠️ بيانات وهمية — استبدل كل دالة بنداء api.get/post لاحقاً
// import { api } from "../../../api";

let SITES = [
  {
    id: 1, nameAr: "مردم نجران الرئيسي", nameEn: "Najran Main Landfill",
    projectId: 1, finalDestinationCode: "FD-1001", wasteTypeCodes: [24, 156, 166],
    totalCapacity: 500000, currentCapacity: 320000, status: "active",
    lat: 17.4917, lng: 44.1322, notes: "", gatesCount: 2,
  },
  {
    id: 2, nameAr: "مردم شرورة", nameEn: "Sharurah Landfill",
    projectId: 2, finalDestinationCode: "FD-1002", wasteTypeCodes: [156],
    totalCapacity: 200000, currentCapacity: 190000, status: "maintenance",
    lat: 17.4833, lng: 47.1167, notes: "", gatesCount: 1,
  },
];

const wait = (v) => new Promise((r) => setTimeout(() => r(v), 300));

export const fetchSites = () => wait([...SITES]);
export const fetchSite = (id) => wait(SITES.find((s) => s.id === Number(id)));
export const createSite = (data) => {
  SITES.push({ ...data, id: Date.now(), gatesCount: 0 });
  return wait(true);
};
export const updateSite = (id, data) => {
  SITES = SITES.map((s) => (s.id === Number(id) ? { ...s, ...data } : s));
  return wait(true);
};
export const deleteSite = (id) => {
  SITES = SITES.filter((s) => s.id !== Number(id));
  return wait(true);
};

// البيانات المرجعية (Lookups) — لا تُثبَّت في الكود مستقبلاً
export const fetchLookups = () =>
  wait({
    projects: [
      { id: 1, name: "مشروع نظافة نجران" },
      { id: 2, name: "مشروع نظافة شرورة" },
    ],
    // من مدينتي: Get Final Destinations
    finalDestinations: [
      { code: "FD-1001", name: "نقطة تخلص نجران" },
      { code: "FD-1002", name: "نقطة تخلص شرورة" },
      { code: "FD-1003", name: "نقطة تخلص بدر الجنوب" },
    ],
    // من مدينتي: WasteTypeCode
    wasteTypes: [
      { code: 24, name: "تجاري" },
      { code: 156, name: "إنشائي" },
      { code: 166, name: "منزلي" },
    ],
  });
