import SiteForm from "./SiteForm";
import { createSite } from "./sitesApi";

export default function AddSite() {
  return (
    <div dir="rtl" className="p-6 max-w-4xl space-y-5">
      <h1 className="text-2xl font-bold text-gray-800">إضافة موقع جديد</h1>
      <SiteForm onSubmit={createSite} submitLabel="إضافة الموقع" />
    </div>
  );
}
