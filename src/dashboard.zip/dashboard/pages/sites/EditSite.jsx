import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import SiteForm from "./SiteForm";
import { fetchSite, updateSite } from "./sitesApi";

export default function EditSite() {
  const { id } = useParams();
  const [site, setSite] = useState(null);

  useEffect(() => {
    fetchSite(id).then(setSite);
  }, [id]);

  if (!site) return <div className="p-6 text-gray-400">جارِ التحميل...</div>;

  return (
    <div dir="rtl" className="p-6 max-w-4xl space-y-5">
      <h1 className="text-2xl font-bold text-gray-800">تعديل الموقع</h1>
      <SiteForm
        initialData={site}
        onSubmit={(data) => updateSite(id, data)}
        submitLabel="حفظ التعديلات"
      />
    </div>
  );
}
