import GateForm from "./GateForm";
import { createGate } from "./gatesApi";

export default function AddGate() {
  return (
    <div dir="rtl" className="p-6 max-w-4xl space-y-5">
      <h1 className="text-2xl font-bold text-gray-800">إضافة بوابة جديدة</h1>
      <GateForm onSubmit={createGate} submitLabel="إضافة البوابة" />
    </div>
  );
}
