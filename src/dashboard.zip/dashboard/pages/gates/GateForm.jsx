import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchGateLookups } from "./gatesApi";

const EMPTY = {
  nameAr: "", siteId: "", type: "weighbridge", direction: "in", status: "active",
  integration: { autoSubmit: true, maxRetries: 5 },
};

const inputCls = "w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500";

function Field({ label, error, children }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      {children}
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </div>
  );
}

export default function GateForm({ initialData, onSubmit, submitLabel = "حفظ" }) {
  const navigate = useNavigate();
  const [form, setForm] = useState(EMPTY);
  const [lookups, setLookups] = useState({ sites: [], types: [], directions: [] });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchGateLookups().then(setLookups);
  }, []);

  useEffect(() => {
    if (initialData) setForm({ ...EMPTY, ...initialData });
  }, [initialData]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const setInt = (k, v) => setForm((f) => ({ ...f, integration: { ...f.integration, [k]: v } }));

  const validate = () => {
    const e = {};
    if (!form.nameAr.trim()) e.nameAr = "اسم البوابة مطلوب";
    if (!form.siteId) e.siteId = "اختر الموقع";
    if (form.integration.maxRetries < 0 || form.integration.maxRetries > 20)
      e.maxRetries = "القيمة بين 0 و 20";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setSaving(true);
    await onSubmit({ ...form, siteId: Number(form.siteId) });
    setSaving(false);
    navigate("/dashboard/gates");
  };

  return (
    <form onSubmit={handleSubmit} dir="rtl" className="space-y-6">
      <section className="bg-white rounded-xl shadow-sm p-5 space-y-4">
        <h2 className="font-semibold text-gray-800">بيانات البوابة</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label="اسم البوابة *" error={errors.nameAr}>
            <input className={inputCls} value={form.nameAr} onChange={(e) => set("nameAr", e.target.value)} />
          </Field>
          <Field label="الموقع *" error={errors.siteId}>
            <select className={inputCls} value={form.siteId} onChange={(e) => set("siteId", e.target.value)}>
              <option value="">اختر...</option>
              {lookups.sites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </Field>
          <Field label="نوع البوابة">
            <select className={inputCls} value={form.type} onChange={(e) => set("type", e.target.value)}>
              {lookups.types.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </Field>
          <Field label="الاتجاه">
            <select className={inputCls} value={form.direction} onChange={(e) => set("direction", e.target.value)}>
              {lookups.directions.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
            </select>
          </Field>
          <Field label="الحالة">
            <select className={inputCls} value={form.status} onChange={(e) => set("status", e.target.value)}>
              <option value="active">نشطة</option>
              <option value="maintenance">صيانة</option>
              <option value="inactive">غير نشطة</option>
            </select>
          </Field>
        </div>
      </section>

      <section className="bg-white rounded-xl shadow-sm p-5 space-y-4">
        <h2 className="font-semibold text-gray-800">إعدادات التكامل مع مدينتي</h2>
        <label className="flex items-center gap-3 cursor-pointer">
          <input type="checkbox" className="w-4 h-4" checked={form.integration.autoSubmit}
            onChange={(e) => setInt("autoSubmit", e.target.checked)} />
          <span className="text-sm text-gray-700">إرسال العمليات تلقائياً عند اكتمالها</span>
        </label>
        <div className="max-w-xs">
          <Field label="عدد محاولات إعادة الإرسال" error={errors.maxRetries}>
            <input type="number" min="0" max="20" className={inputCls} value={form.integration.maxRetries}
              onChange={(e) => setInt("maxRetries", Number(e.target.value))} />
          </Field>
        </div>
      </section>

      <div className="flex gap-3">
        <button type="submit" disabled={saving}
          className="bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white px-6 py-2 rounded-lg text-sm">
          {saving ? "جارِ الحفظ..." : submitLabel}
        </button>
        <button type="button" onClick={() => navigate("/dashboard/gates")}
          className="border px-6 py-2 rounded-lg text-sm hover:bg-gray-50">إلغاء</button>
      </div>
    </form>
  );
}
