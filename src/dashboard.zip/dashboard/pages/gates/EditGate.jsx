import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import GateForm from "./GateForm";
import { fetchGate, updateGate } from "./gatesApi";

export default function EditGate() {
  const { id } = useParams();
  const [gate, setGate] = useState(null);

  useEffect(() => {
    fetchGate(id).then(setGate);
  }, [id]);

  if (!gate) return <div className="p-6 text-gray-400">جارِ التحميل...</div>;

  return (
    <div dir="rtl" className="p-6 max-w-4xl space-y-5">
      <h1 className="text-2xl font-bold text-gray-800">تعديل البوابة</h1>
      <GateForm initialData={gate} onSubmit={(d) => updateGate(id, d)} submitLabel="حفظ التعديلات" />
    </div>
  );
}
