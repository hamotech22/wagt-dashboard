// ⚠️ بيانات وهمية — استبدل كل دالة بنداء api.get/post لاحقاً
// import { api } from "../../../api";

let GATES = [
  {
    id: 1, nameAr: "بوابة الدخول الرئيسية", siteId: 1, type: "weighbridge",
    direction: "in", status: "active", connectionStatus: "online",
    lastConnection: "2026-09-20T05:58:00",
    integration: { autoSubmit: true, maxRetries: 5 },
    devices: [
      { id: 11, type: "anpr", name: "كاميرا ANPR-01", status: "online" },
      { id: 12, type: "scale", name: "ميزان 60 طن", status: "online" },
      { id: 13, type: "controller", name: "متحكم البوابة", status: "online" },
    ],
  },
  {
    id: 2, nameAr: "بوابة الخروج الرئيسية", siteId: 1, type: "weighbridge",
    direction: "out", status: "active", connectionStatus: "offline",
    lastConnection: "2026-09-20T03:10:00",
    integration: { autoSubmit: true, maxRetries: 5 },
    devices: [
      { id: 21, type: "anpr", name: "كاميرا ANPR-02", status: "offline" },
      { id: 22, type: "scale", name: "ميزان 60 طن", status: "online" },
    ],
  },
  {
    id: 3, nameAr: "بوابة شرورة", siteId: 2, type: "standard",
    direction: "both", status: "maintenance", connectionStatus: "offline",
    lastConnection: "2026-09-18T12:00:00",
    integration: { autoSubmit: false, maxRetries: 3 },
    devices: [],
  },
];

const wait = (v) => new Promise((r) => setTimeout(() => r(v), 300));

export const fetchGates = () => wait([...GATES]);
export const fetchGate = (id) => wait(GATES.find((g) => g.id === Number(id)));
export const createGate = (data) => {
  GATES.push({
    ...data, id: Date.now(), connectionStatus: "offline",
    lastConnection: null, devices: [],
  });
  return wait(true);
};
export const updateGate = (id, data) => {
  GATES = GATES.map((g) => (g.id === Number(id) ? { ...g, ...data } : g));
  return wait(true);
};
export const deleteGate = (id) => {
  GATES = GATES.filter((g) => g.id !== Number(id));
  return wait(true);
};

// Lookups
export const fetchGateLookups = () =>
  wait({
    sites: [
      { id: 1, name: "مردم نجران الرئيسي" },
      { id: 2, name: "مردم شرورة" },
    ],
    types: [
      { value: "weighbridge", label: "بوابة بميزان" },
      { value: "standard", label: "بوابة عادية" },
    ],
    directions: [
      { value: "in", label: "دخول" },
      { value: "out", label: "خروج" },
      { value: "both", label: "دخول وخروج" },
    ],
  });
