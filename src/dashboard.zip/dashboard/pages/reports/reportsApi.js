// ⚠️ بيانات وهمية — استبدل fetchReport بنداء: api.get("/reports/:type", { params })
// الـ Backend هو من يجمّع ويفلتر حسب صلاحيات المستخدم (Data Scope)
import { COLUMNS, STATUS_LABEL } from "./reportDefs";

const wait = (v) => new Promise((r) => setTimeout(() => r(v), 350));

// ---------- بيانات وهمية ثابتة (نفس النتيجة كل مرة) ----------
function rng(seed) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const LOOK = {
  sites: [{ id: 1, name: "مردم نجران الرئيسي" }, { id: 2, name: "مردم شرورة" }],
  gates: [
    { id: 1, name: "بوابة الدخول الرئيسية", siteId: 1 },
    { id: 2, name: "بوابة الخروج الرئيسية", siteId: 1 },
    { id: 3, name: "بوابة شرورة", siteId: 2 },
  ],
  contractors: [{ id: 1, name: "شركة النظافة المتحدة" }, { id: 2, name: "مؤسسة الجنوب للمقاولات" }],
  projects: [{ id: 1, name: "مشروع نظافة نجران" }, { id: 2, name: "مشروع نظافة شرورة" }],
  wasteTypes: [{ code: 24, name: "تجاري" }, { code: 156, name: "إنشائي" }, { code: 166, name: "منزلي" }],
  statuses: Object.entries(STATUS_LABEL).map(([value, label]) => ({ value, label })),
};

const VEHICLES = [
  { key: "1234", num: "1234", chars: "أ ب ج", contractorId: 1, projectId: 1, siteId: 1 },
  { key: "5678", num: "5678", chars: "د هـ و", contractorId: 1, projectId: 1, siteId: 1 },
  { key: "9012", num: "9012", chars: "ر س ص", contractorId: 2, projectId: 2, siteId: 2 },
  { key: "7788", num: "7788", chars: "ل م ن", contractorId: 2, projectId: 2, siteId: 2 },
];

const R = rng(42);
const DAY = 86400000;
const TX = Array.from({ length: 80 }, (_, i) => {
  const v = VEHICLES[Math.floor(R() * VEHICLES.length)];
  const entry = Date.now() - R() * 30 * DAY;
  const inW = 12000 + Math.floor(R() * 14000);
  const outW = 8000 + Math.floor(R() * 3000);
  const roll = R();
  const status = roll < 0.85 ? "completed" : roll < 0.93 ? "cancelled" : "rejected";
  return {
    id: 200 + i, vehicle: v, contractorId: v.contractorId, projectId: v.projectId, siteId: v.siteId,
    entryGateId: v.siteId === 1 ? (R() < 0.7 ? 1 : 2) : 3,
    wasteTypeCode: LOOK.wasteTypes[Math.floor(R() * 3)].code,
    entryAt: new Date(entry).toISOString(),
    exitAt: status === "completed" ? new Date(entry + (0.5 + R() * 1.5) * 3600000).toISOString() : null,
    inWeight: status === "completed" ? inW : null,
    outWeight: status === "completed" ? outW : null,
    status,
  };
});

const DEVICES = [
  { name: "كاميرا ANPR-01", type: "كاميرا ANPR", gate: "بوابة الدخول الرئيسية", connection: "متصل", lastSeen: new Date().toISOString() },
  { name: "ميزان 60 طن", type: "ميزان", gate: "بوابة الدخول الرئيسية", connection: "متصل", lastSeen: new Date().toISOString() },
  { name: "كاميرا ANPR-02", type: "كاميرا ANPR", gate: "بوابة الخروج الرئيسية", connection: "غير متصل", lastSeen: new Date(Date.now() - 3 * 3600000).toISOString() },
  { name: "كاميرا المركبة", type: "كاميرا", gate: "بوابة الخروج الرئيسية", connection: "غير متصل", lastSeen: null },
];

// ---------- مساعدات ----------
const nameOf = (list, v, key = "id") => list.find((x) => x[key] === v)?.name || "-";
const net = (t) => (t.inWeight != null && t.outWeight != null ? (t.inWeight - t.outWeight) / 1000 : null);

function periodKey(iso, period) {
  const d = new Date(iso);
  if (period === "month") return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  if (period === "week") {
    const s = new Date(d); s.setDate(d.getDate() - d.getDay()); // الأحد
    return `أسبوع ${s.toISOString().slice(0, 10)}`;
  }
  return d.toISOString().slice(0, 10);
}

function group(list, keyFn) {
  const map = new Map();
  list.forEach((t) => {
    const k = keyFn(t);
    if (!map.has(k)) map.set(k, { name: k, count: 0, tons: 0, weighed: 0, plates: new Set() });
    const g = map.get(k);
    g.count += 1;
    g.plates.add(t.vehicle.key);
    const n = net(t);
    if (n != null) { g.tons += n; g.weighed += 1; }
  });
  return [...map.values()].map((g) => ({
    name: g.name,
    count: g.count,
    vehicles: g.plates.size,
    netTons: +g.tons.toFixed(2),
    avgTons: g.weighed ? +(g.tons / g.weighed).toFixed(2) : 0,
  }));
}

// ---------- API ----------
export const fetchReportLookups = () => wait(LOOK);

export async function fetchReport(type, f = {}, period = "day") {
  if (type === "devices") return wait({ columns: COLUMNS.devices, rows: DEVICES });

  const q = (f.plate || "").replace(/\s/g, "");
  const list = TX.filter(
    (t) =>
      (!f.from || new Date(t.entryAt) >= new Date(f.from)) &&
      (!f.to || new Date(t.entryAt) <= new Date(f.to + "T23:59:59")) &&
      (!f.siteId || t.siteId === Number(f.siteId)) &&
      (!f.contractorId || t.contractorId === Number(f.contractorId)) &&
      (!f.projectId || t.projectId === Number(f.projectId)) &&
      (!f.gateId || t.entryGateId === Number(f.gateId)) &&
      (!f.waste || t.wasteTypeCode === Number(f.waste)) &&
      (!f.status || t.status === f.status) &&
      (!q || (t.vehicle.num + t.vehicle.chars.replace(/\s/g, "")).includes(q))
  );

  let rows;
  switch (type) {
    case "movements":
      rows = list.map((t) => ({
        code: `TX-${String(t.id).padStart(6, "0")}`,
        plate: `${t.vehicle.num} ${t.vehicle.chars}`,
        contractor: nameOf(LOOK.contractors, t.contractorId),
        site: nameOf(LOOK.sites, t.siteId),
        waste: nameOf(LOOK.wasteTypes, t.wasteTypeCode, "code"),
        entryAt: t.entryAt,
        exitAt: t.exitAt,
        inTons: t.inWeight != null ? t.inWeight / 1000 : null,
        outTons: t.outWeight != null ? t.outWeight / 1000 : null,
        netTons: net(t),
        status: STATUS_LABEL[t.status],
      }));
      break;
    case "byWasteType": rows = group(list, (t) => nameOf(LOOK.wasteTypes, t.wasteTypeCode, "code")); break;
    case "byContractor": rows = group(list, (t) => nameOf(LOOK.contractors, t.contractorId)); break;
    case "byProject": rows = group(list, (t) => nameOf(LOOK.projects, t.projectId)); break;
    case "bySite": rows = group(list, (t) => nameOf(LOOK.sites, t.siteId)); break;
    case "byGate": rows = group(list, (t) => nameOf(LOOK.gates, t.entryGateId)); break;
    case "byPeriod": rows = group(list, (t) => periodKey(t.entryAt, period)); break;
    default: rows = [];
  }
  return wait({ columns: COLUMNS[type], rows });
}
