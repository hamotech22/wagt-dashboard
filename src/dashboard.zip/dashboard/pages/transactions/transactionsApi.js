// ⚠️ بيانات وهمية — استبدل كل دالة بنداء api.get/post لاحقاً
// import { api } from "../../../api";
// الأوزان بالكيلوجرام، وصافي النفايات = وزن الدخول (محمّلة) − وزن الخروج (فارغة)

const H = 3600 * 1000;
const ago = (h) => new Date(Date.now() - h * H).toISOString();

let TX = [
  { id: 101, plateNumber: "1234", plateChars: "أ ب ج", contractorId: 1, projectId: 1, siteId: 1,
    entryGateId: 1, exitGateId: 2, wasteTypeCode: 166, driverName: "محمد علي",
    inWeight: 18500, outWeight: 9800, entryAt: ago(5), exitAt: ago(4.2), status: "completed", note: "" },
  { id: 102, plateNumber: "5678", plateChars: "د هـ و", contractorId: 1, projectId: 1, siteId: 1,
    entryGateId: 1, exitGateId: 2, wasteTypeCode: 156, driverName: "سعيد ناصر",
    inWeight: 24200, outWeight: 11000, entryAt: ago(3), exitAt: ago(2.3), status: "completed", note: "" },
  { id: 103, plateNumber: "1234", plateChars: "أ ب ج", contractorId: 1, projectId: 1, siteId: 1,
    entryGateId: 1, exitGateId: null, wasteTypeCode: 166, driverName: "محمد علي",
    inWeight: 17900, outWeight: null, entryAt: ago(1), exitAt: null, status: "inside", note: "" },
  { id: 104, plateNumber: "9012", plateChars: "ر س ص", contractorId: 2, projectId: 2, siteId: 2,
    entryGateId: 3, exitGateId: null, wasteTypeCode: 24, driverName: "عبدالله فهد",
    inWeight: 15100, outWeight: null, entryAt: ago(0.5), exitAt: null, status: "inside", note: "" },
  { id: 105, plateNumber: "5678", plateChars: "د هـ و", contractorId: 1, projectId: 1, siteId: 1,
    entryGateId: 1, exitGateId: 2, wasteTypeCode: 156, driverName: "سعيد ناصر",
    inWeight: 23800, outWeight: 10900, entryAt: ago(29), exitAt: ago(28), status: "completed", note: "" },
  { id: 106, plateNumber: "3456", plateChars: "ط ع ك", contractorId: null, projectId: null, siteId: 1,
    entryGateId: 1, exitGateId: null, wasteTypeCode: null, driverName: "",
    inWeight: null, outWeight: null, entryAt: ago(26), exitAt: null, status: "rejected",
    note: "مركبة غير مسجلة في النظام" },
  { id: 107, plateNumber: "9012", plateChars: "ر س ص", contractorId: 2, projectId: 2, siteId: 2,
    entryGateId: 3, exitGateId: null, wasteTypeCode: 24, driverName: "عبدالله فهد",
    inWeight: 14800, outWeight: null, entryAt: ago(50), exitAt: null, status: "cancelled",
    note: "تسجيل مكرر بالخطأ" },
];

const wait = (v) => new Promise((r) => setTimeout(() => r(v), 300));

// إضافة صافي النفايات
const withWaste = (t) => ({
  ...t,
  wasteWeight: t.inWeight != null && t.outWeight != null ? t.inWeight - t.outWeight : null,
  images: { plate: null, entry: null, exit: null }, // لاحقاً: روابط من Object Storage
});

export const fetchTransactions = () => wait(TX.map(withWaste));
export const fetchTransaction = (id) => wait(withWaste(TX.find((t) => t.id === Number(id))));

export const cancelTransaction = (id, reason) => {
  TX = TX.map((t) => (t.id === Number(id) ? { ...t, status: "cancelled", note: reason } : t));
  return wait(true);
};

export const fetchTransactionLookups = () =>
  wait({
    sites: [
      { id: 1, name: "مردم نجران الرئيسي" },
      { id: 2, name: "مردم شرورة" },
    ],
    gates: [
      { id: 1, name: "بوابة الدخول الرئيسية" },
      { id: 2, name: "بوابة الخروج الرئيسية" },
      { id: 3, name: "بوابة شرورة" },
    ],
    contractors: [
      { id: 1, name: "شركة النظافة المتحدة" },
      { id: 2, name: "مؤسسة الجنوب للمقاولات" },
    ],
    projects: [
      { id: 1, name: "مشروع نظافة نجران" },
      { id: 2, name: "مشروع نظافة شرورة" },
    ],
    // بند 12 — يجب أن تُدار كبيانات مرجعية لا داخل الكود
    wasteTypes: [
      { code: 24, name: "تجاري" },
      { code: 156, name: "إنشائي" },
      { code: 166, name: "منزلي" },
    ],
  });
