// ⚠️ بيانات وهمية — استبدل بنداء api.get("/notifications") ...
// الأنواع من بند 47 (بدون تنبيهات مدينتي حالياً)
const M = 60000;
const ago = (m) => new Date(Date.now() - m * M).toISOString();

let N = [
  { id: 1, type: "gate_offline", severity: "critical", title: "بوابة الخروج الرئيسية غير متصلة",
    message: "لم تصل أي نبضة من البوابة منذ أكثر من ساعتين.", createdAt: ago(130),
    read: false, resolved: false, link: "/dashboard/gates/2" },
  { id: 2, type: "anpr_offline", severity: "critical", title: "كاميرا ANPR-02 غير متصلة",
    message: "الكاميرا لا تستجيب، قد تفشل قراءة اللوحات عند بوابة الخروج.", createdAt: ago(125),
    read: false, resolved: false, link: "/dashboard/devices/21" },
  { id: 3, type: "scale_offline", severity: "critical", title: "ميزان بوابة شرورة غير متصل",
    message: "لا يمكن تسجيل الأوزان حتى يعود الاتصال.", createdAt: ago(45),
    read: false, resolved: false, link: "/dashboard/gates/3" },
  { id: 4, type: "unknown_vehicle", severity: "warning", title: "مركبة غير معروفة: 3456 ط ع ك",
    message: "اكتُشفت عند بوابة الدخول ولم تُربط بمقاول أو مشروع.", createdAt: ago(200),
    read: false, resolved: false, link: "/dashboard/vehicles/4" },
  { id: 5, type: "open_transaction", severity: "warning", title: "عملية مفتوحة لفترة أطول من المعتاد",
    message: "مركبة داخل الموقع منذ وقت طويل دون تسجيل خروج.", createdAt: ago(90),
    read: true, resolved: false, link: "/dashboard/transactions/103" },
  { id: 6, type: "incomplete_weight", severity: "warning", title: "وزن غير مكتمل",
    message: "عملية دخول بدون وزن خروج مسجّل.", createdAt: ago(70),
    read: false, resolved: false, link: "/dashboard/transactions/104" },
  { id: 7, type: "missing_data", severity: "info", title: "بيانات إلزامية ناقصة",
    message: "عملية بدون اسم سائق أو نوع نفايات.", createdAt: ago(1500),
    read: true, resolved: false, link: "/dashboard/transactions/106" },
  { id: 8, type: "gate_offline", severity: "critical", title: "بوابة الدخول الرئيسية غير متصلة",
    message: "عاد الاتصال بعد انقطاع دام 12 دقيقة.", createdAt: ago(2900),
    read: true, resolved: true, link: "/dashboard/gates/1" },
];

const wait = (v) => new Promise((r) => setTimeout(() => r(v), 250));

export const fetchNotifications = () => wait([...N].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
export const markRead = (id) => { N = N.map((n) => (n.id === id ? { ...n, read: true } : n)); return wait(true); };
export const markAllRead = () => { N = N.map((n) => ({ ...n, read: true })); return wait(true); };
export const resolveNotification = (id) => { N = N.map((n) => (n.id === id ? { ...n, resolved: true, read: true } : n)); return wait(true); };

// أنواع التنبيهات — تُدار كبيانات لا كود ثابت
export const TYPES = {
  gate_offline: { label: "بوابة غير متصلة", icon: "🚪" },
  anpr_offline: { label: "كاميرا ANPR غير متصلة", icon: "📷" },
  scale_offline: { label: "ميزان غير متصل", icon: "⚖️" },
  open_transaction: { label: "عملية مفتوحة طويلاً", icon: "⏳" },
  unknown_vehicle: { label: "مركبة غير معروفة", icon: "🚛" },
  missing_data: { label: "بيانات ناقصة", icon: "📝" },
  incomplete_weight: { label: "وزن غير مكتمل", icon: "⚠️" },
};

export const SEVERITY = {
  critical: { label: "حرج", bar: "border-red-500", badge: "bg-red-100 text-red-700" },
  warning: { label: "تحذير", bar: "border-yellow-500", badge: "bg-yellow-100 text-yellow-700" },
  info: { label: "معلومة", bar: "border-blue-400", badge: "bg-blue-100 text-blue-700" },
};
