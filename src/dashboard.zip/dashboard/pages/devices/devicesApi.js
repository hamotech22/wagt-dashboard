// ⚠️ بيانات وهمية — استبدل كل دالة بنداء api.get/post لاحقاً
// import { api } from "../../../api";

let DEVICES = [
  { id: 11, nameAr: "كاميرا ANPR-01", type: "anpr", gateId: 1, connectionId: "ANPR-NJR-001",
    ip: "192.168.1.21", firmware: "v2.4.1", installDate: "2026-03-10",
    status: "active", connectionStatus: "online", lastSeen: "2026-09-20T06:01:00" },
  { id: 12, nameAr: "ميزان 60 طن", type: "scale", gateId: 1, connectionId: "SCALE-NJR-001",
    ip: "192.168.1.22", firmware: "v1.9.0", installDate: "2026-03-10",
    status: "active", connectionStatus: "online", lastSeen: "2026-09-20T06:01:00" },
  { id: 13, nameAr: "متحكم البوابة", type: "controller", gateId: 1, connectionId: "CTRL-NJR-001",
    ip: "", firmware: "", installDate: "2026-03-11",
    status: "active", connectionStatus: "online", lastSeen: "2026-09-20T05:59:00" },
  { id: 21, nameAr: "كاميرا ANPR-02", type: "anpr", gateId: 2, connectionId: "ANPR-NJR-002",
    ip: "192.168.1.31", firmware: "v2.4.1", installDate: "2026-03-12",
    status: "active", connectionStatus: "offline", lastSeen: "2026-09-20T03:10:00" },
  { id: 22, nameAr: "كاميرا المركبة", type: "camera", gateId: 2, connectionId: "CAM-NJR-002",
    ip: "192.168.1.32", firmware: "", installDate: "2026-03-12",
    status: "maintenance", connectionStatus: "offline", lastSeen: null },
];

const wait = (v) => new Promise((r) => setTimeout(() => r(v), 300));

export const fetchDevices = () => wait([...DEVICES]);
export const fetchDevice = (id) => wait(DEVICES.find((d) => d.id === Number(id)));
export const createDevice = (data) => {
  DEVICES.push({ ...data, id: Date.now(), connectionStatus: "offline", lastSeen: null });
  return wait(true);
};
export const updateDevice = (id, data) => {
  DEVICES = DEVICES.map((d) => (d.id === Number(id) ? { ...d, ...data } : d));
  return wait(true);
};
export const deleteDevice = (id) => {
  DEVICES = DEVICES.filter((d) => d.id !== Number(id));
  return wait(true);
};

export const fetchDeviceLookups = () =>
  wait({
    gates: [
      { id: 1, name: "بوابة الدخول الرئيسية" },
      { id: 2, name: "بوابة الخروج الرئيسية" },
      { id: 3, name: "بوابة شرورة" },
    ],
    // بند 9 من الوثيقة
    types: [
      { value: "anpr", label: "كاميرا ANPR" },
      { value: "camera", label: "كاميرا المركبة" },
      { value: "scale", label: "ميزان / Weighbridge" },
      { value: "controller", label: "متحكم البوابة" },
      { value: "sensor", label: "حساس" },
      { value: "access", label: "جهاز تحكم دخول" },
    ],
  });
