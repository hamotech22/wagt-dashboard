import DeviceForm from "./DeviceForm";
import { createDevice } from "./devicesApi";

export default function AddDevice() {
  return (
    <div dir="rtl" className="p-6 max-w-4xl space-y-5">
      <h1 className="text-2xl font-bold text-gray-800">إضافة جهاز جديد</h1>
      <DeviceForm onSubmit={createDevice} submitLabel="إضافة الجهاز" />
    </div>
  );
}
