import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import DeviceForm from "./DeviceForm";
import { fetchDevice, updateDevice } from "./devicesApi";

export default function EditDevice() {
  const { id } = useParams();
  const [device, setDevice] = useState(null);

  useEffect(() => {
    fetchDevice(id).then(setDevice);
  }, [id]);

  if (!device) return <div className="p-6 text-gray-400">جارِ التحميل...</div>;

  return (
    <div dir="rtl" className="p-6 max-w-4xl space-y-5">
      <h1 className="text-2xl font-bold text-gray-800">تعديل الجهاز</h1>
      <DeviceForm initialData={device} onSubmit={(d) => updateDevice(id, d)} submitLabel="حفظ التعديلات" />
    </div>
  );
}
