import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { organizationsApi } from "./organizationsData";

const EMPTY = {
  name: "",
  code: "",
  slug: "",
  municipalityCode: "",
  email: "",
  phone: "",
  website: "",
  city: "",
  region: "",
  address: "",
  status: "active",
};

const inputCls =
  "h-11 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-800 outline-none transition focus:border-sky-500 focus:ring-2 focus:ring-sky-100";

const STATUS_OPTIONS = [
  { value: "active", label: "نشطة" },
  { value: "inactive", label: "غير نشطة" },
];

function Card({ title, description, children }) {
  return (
    <section className="rounded-xl bg-white shadow-sm ring-1 ring-slate-200/70">
      <header className="border-b border-slate-100 px-6 py-4">
        <h2 className="font-semibold text-slate-900">{title}</h2>
        {description && <p className="mt-0.5 text-sm text-slate-500">{description}</p>}
      </header>
      <div className="p-6">{children}</div>
    </section>
  );
}

function Field({ label, required, error, hint, children, className = "" }) {
  return (
    <label className={`block text-sm text-slate-700 ${className}`}>
      <span className="mb-1.5 flex items-center gap-1 font-medium">
        {label}
        {required && <span className="text-red-500">*</span>}
      </span>
      {children}
      {hint && <span className="mt-1 block text-xs text-slate-500">{hint}</span>}
      {error && <span className="mt-1 block text-xs text-red-600">{error}</span>}
    </label>
  );
}

export default function AddOrganization() {
  const navigate = useNavigate();

  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");

  const dirty = useMemo(() => JSON.stringify(form) !== JSON.stringify(EMPTY), [form]);

  const set = (patch) => {
    setForm((current) => ({ ...current, ...patch }));
    setErrors((current) => {
      const next = { ...current };
      Object.keys(patch).forEach((key) => delete next[key]);
      return next;
    });
  };

  const validate = () => {
    const nextErrors = {};
    if (!form.name.trim()) nextErrors.name = "أدخل اسم الجهة";
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) nextErrors.email = "أدخل بريدًا إلكترونيًا صحيحًا";
    if (form.website && !/^https?:\/\//i.test(form.website)) nextErrors.website = "يجب أن يبدأ الرابط بـ http:// أو https://";
    setErrors(nextErrors);
    return nextErrors;
  };

  const save = async () => {
    setSaving(true);
    setSaveError("");
    try {
      await organizationsApi.create({ ...form, name: form.name.trim() });
      navigate("/dashboard/organizations");
    } catch (err) {
      setSaveError(err.message || "تعذّر حفظ الجهة");
      setSaving(false);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (saving) return;
    const nextErrors = validate();
    if (Object.keys(nextErrors).length > 0) {
      setTimeout(() => {
        const firstInvalid = document.querySelector('[aria-invalid="true"]');
        firstInvalid?.scrollIntoView({ block: "center", behavior: "smooth" });
        firstInvalid?.focus();
      }, 0);
      return;
    }
    save();
  };

  const handleCancel = () => {
    if (dirty) {
      const shouldLeave = window.confirm("هل تريد الخروج بدون حفظ التغييرات؟");
      if (!shouldLeave) return;
    }
    navigate("/dashboard/organizations");
  };

  // تحذير عند إغلاق الصفحة مع وجود تغييرات غير محفوظة
  useEffect(() => {
    if (!dirty) return;

    const warn = (event) => {
      event.preventDefault();
      event.returnValue = "";
    };

    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);

  return (
    <div className="p-6">
      <nav aria-label="مسار التنقل" className="mb-2 flex items-center gap-2 text-sm text-slate-500">
        <button type="button" onClick={handleCancel} className="hover:text-sky-600">
          الجهات والبلديات
        </button>
        <span aria-hidden="true">/</span>
        <span className="text-slate-800">إضافة جهة</span>
      </nav>

      <h1 className="text-xl font-bold text-slate-900">إضافة جهة</h1>
      <p className="mt-1 text-sm text-slate-500">أدخل بيانات الجهة أو البلدية. الحقول المعلَّمة بـ * مطلوبة.</p>

      <form onSubmit={handleSubmit} noValidate className="mt-6 space-y-6">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            <Card title="المعلومات الأساسية">
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <Field label="اسم الجهة" required error={errors.name} className="sm:col-span-2">
                  <input
                    className={inputCls}
                    value={form.name}
                    onChange={(event) => set({ name: event.target.value })}
                    aria-invalid={Boolean(errors.name)}
                    placeholder="مثال: أمانة منطقة نجران"
                    autoFocus
                  />
                </Field>

                <Field label="رمز الجهة" hint="اتركه فارغًا ليُولَّد تلقائيًا">
                  <input
                    className={inputCls}
                    dir="ltr"
                    value={form.code}
                    onChange={(event) => set({ code: event.target.value })}
                    placeholder="ORG-001"
                  />
                </Field>

                <Field
                  label="النطاق الفرعي"
                  hint="يظهر في الرابط بعد الدخول، مثال: /najran/dashboard"
                  className="sm:col-span-2"
                >
                  <input
                    className={inputCls}
                    dir="ltr"
                    value={form.slug}
                    onChange={(event) => set({ slug: event.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "") })}
                    placeholder="najran"
                  />
                </Field>

                <Field label="كود البلدية في مدينتي" hint="المرجع الخارجي (MunicipalityCode)، إن وُجد">
                  <input
                    className={inputCls}
                    dir="ltr"
                    value={form.municipalityCode}
                    onChange={(event) => set({ municipalityCode: event.target.value })}
                    placeholder="9"
                  />
                </Field>
              </div>
            </Card>

            <Card title="معلومات التواصل" description="بيانات التواصل الرسمية مع الجهة.">
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <Field label="البريد الإلكتروني" error={errors.email} className="sm:col-span-2">
                  <input
                    type="email"
                    className={inputCls}
                    dir="ltr"
                    value={form.email}
                    onChange={(event) => set({ email: event.target.value })}
                    aria-invalid={Boolean(errors.email)}
                    placeholder="example@email.com"
                  />
                </Field>

                <Field label="رقم الهاتف">
                  <input
                    className={inputCls}
                    dir="ltr"
                    value={form.phone}
                    onChange={(event) => set({ phone: event.target.value })}
                    placeholder="+966 5XXXXXXXX"
                  />
                </Field>

                <Field label="الموقع الإلكتروني" error={errors.website}>
                  <input
                    className={inputCls}
                    dir="ltr"
                    value={form.website}
                    onChange={(event) => set({ website: event.target.value })}
                    aria-invalid={Boolean(errors.website)}
                    placeholder="https://website.com"
                  />
                </Field>
              </div>
            </Card>

            <Card title="الموقع" description="موقع الجهة وعنوانها.">
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <Field label="المدينة">
                  <input
                    className={inputCls}
                    value={form.city}
                    onChange={(event) => set({ city: event.target.value })}
                    placeholder="المدينة"
                  />
                </Field>

                <Field label="المنطقة">
                  <input
                    className={inputCls}
                    value={form.region}
                    onChange={(event) => set({ region: event.target.value })}
                    placeholder="المنطقة"
                  />
                </Field>

                <Field label="العنوان التفصيلي" className="sm:col-span-2">
                  <textarea
                    rows={3}
                    className={`${inputCls} h-auto py-2`}
                    value={form.address}
                    onChange={(event) => set({ address: event.target.value })}
                    placeholder="اسم الحي، الشارع، رقم المبنى"
                  />
                </Field>
              </div>
            </Card>
          </div>

          <div className="space-y-6">
            <Card title="الحالة">
              <Field label="حالة الجهة">
                <select className={inputCls} value={form.status} onChange={(event) => set({ status: event.target.value })}>
                  {STATUS_OPTIONS.map((status) => (
                    <option key={status.value} value={status.value}>
                      {status.label}
                    </option>
                  ))}
                </select>
              </Field>
            </Card>

            <Card title="حفظ الجهة">
              <div className="space-y-4">
                {saveError && <div className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{saveError}</div>}

                <button
                  type="submit"
                  disabled={saving}
                  className="h-11 w-full rounded-lg bg-sky-600 px-4 text-sm font-medium text-white transition hover:bg-sky-500 disabled:cursor-not-allowed disabled:bg-slate-300"
                >
                  {saving ? "جارٍ الحفظ..." : "حفظ الجهة"}
                </button>

                <button
                  type="button"
                  onClick={handleCancel}
                  className="h-11 w-full rounded-lg border border-slate-200 bg-white px-4 text-sm text-slate-700 transition hover:bg-slate-50"
                >
                  إلغاء
                </button>
              </div>
            </Card>
          </div>
        </div>
      </form>
    </div>
  );
}
