// imports

export default function OrganizationDetails() {
  // state, functions, effects, API calls...

  return (
    <div>
      <h3>OrganizationDetails component</h3>
    </div>
  )
}