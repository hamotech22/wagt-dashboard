// imports

export default function EditOrganization() {
  // state, functions, effects, API calls...

  return (
    <div>
      <h3>EditOrganization component</h3>
    </div>
  )
}