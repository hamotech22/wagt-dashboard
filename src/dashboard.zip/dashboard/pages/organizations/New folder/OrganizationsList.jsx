export default function OrganizationsList() {
  const organizations = [
    {
      id: 1,
      name: "بلدية الرياض",
      code: "ORG-001",
      location: "الرياض",
      projects: 25,
      status: "نشطة",
    },
    {
      id: 2,
      name: "بلدية جدة",
      code: "ORG-002",
      location: "جدة",
      projects: 18,
      status: "نشطة",
    },
  ];

  return (
    <div dir="rtl" className="min-h-screen bg-slate-100 p-6 md:p-10">
      <div className="w-full space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-blue-900">الجهات</h1>
            <p className="mt-1 text-sm text-slate-500">إدارة الجهات والبلديات</p>
          </div>

          <button className="rounded bg-blue-600 px-5 py-2 text-sm font-medium text-white hover:bg-blue-700">+ إضافة جهة</button>
        </div>

        {/* Card */}
        <div className="rounded-md border border-slate-200 bg-white p-6 shadow-sm md:p-8">
          {/* Search */}
          <input
            placeholder="ابحث عن جهة..."
            className="mb-6 w-full rounded border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
          />

          {/* List */}
          <div className="divide-y divide-slate-200 border-t border-slate-200">
            {organizations.map((item) => (
              <div key={item.id} className="flex flex-wrap items-center justify-between gap-4 py-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded border border-slate-200 bg-slate-50 text-lg">🏢</div>
                  <div>
                    <h2 className="text-sm font-semibold text-slate-800">{item.name}</h2>
                    <p className="text-sm text-slate-500">{item.code}</p>
                  </div>
                </div>

                <div className="flex items-center gap-8">
                  <div>
                    <p className="text-xs text-slate-400">الموقع</p>
                    <p className="text-sm font-medium text-slate-800">{item.location}</p>
                  </div>

                  <div>
                    <p className="text-xs text-slate-400">المشاريع</p>
                    <p className="text-sm font-medium text-slate-800">{item.projects}</p>
                  </div>

                  <span className="rounded border border-green-200 bg-green-50 px-3 py-1 text-xs font-medium text-green-700">
                    {item.status}
                  </span>

                  <button className="text-slate-400 hover:text-slate-700">⋮</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
