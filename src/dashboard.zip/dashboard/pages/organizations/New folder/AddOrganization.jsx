import { useState } from "react";

const sections = [
  {
    title: "المعلومات الأساسية",
    fields: [
      { label: "اسم الجهة", placeholder: "أدخل اسم الجهة", span: 2 },
      { label: "رمز الجهة", placeholder: "ORG-001", span: 2 },
    ],
  },
  {
    title: "معلومات التواصل",
    fields: [
      { label: "البريد الإلكتروني", placeholder: "example@email.com", span: 2 },
      { label: "رقم الهاتف", placeholder: "+966 5XXXXXXXX", span: 1 },
      { label: "الموقع الإلكتروني", placeholder: "https://website.com", span: 1 },
    ],
  },
  {
    title: "الموقع",
    fields: [
      { label: "المدينة", placeholder: "المدينة", span: 2 },
      { label: "المنطقة", placeholder: "المنطقة", span: 1 },
      { label: "العنوان التفصيلي", placeholder: "اسم الحي، الشارع، رقم المبنى", span: 1 },
    ],
  },
];

export default function AddOrganization() {
  const [active, setActive] = useState(true);

  return (
    <div dir="rtl" className="min-h-screen bg-slate-100 p-6 md:p-10">
      <div className="mx-auto w-full">
        {/* Breadcrumb */}
        <div className="mb-4 text-sm text-slate-500">
          الرئيسية <span className="mx-1">/</span> الجهات والبلديات{" "}
          <span className="mx-1">/</span>
          <span className="text-slate-700"> إضافة جهة</span>
        </div>

        {/* Card */}
        <div className="rounded-md border border-slate-200 bg-white p-6 shadow-sm md:p-8">
          <h1 className="mb-6 text-xl font-bold text-blue-900">إضافة جهة جديدة</h1>

          {sections.map((section) => (
            <div key={section.title} className="mb-6">
              <h2 className="mb-3 text-base font-semibold text-slate-800">
                {section.title}
              </h2>
              <div className="grid gap-4 sm:grid-cols-2">
                {section.fields.map((field) => (
                  <div
                    key={field.label}
                    className={field.span === 2 ? "sm:col-span-2" : "sm:col-span-1"}
                  >
                    <label className="mb-1.5 block text-sm text-slate-700">
                      {field.label}
                    </label>
                    <input
                      placeholder={field.placeholder}
                      className="w-full rounded border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Status checkbox */}
          <div className="mb-6 flex items-center gap-2">
            <input
              type="checkbox"
              id="active"
              checked={active}
              onChange={(e) => setActive(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor="active" className="text-sm text-slate-700">
              الجهة نشطة
            </label>
          </div>

          {/* Actions */}
          <div className="flex justify-center gap-3">
            <button className="rounded bg-blue-600 px-6 py-2 text-sm font-medium text-white hover:bg-blue-700">
              حفظ الجهة
            </button>
            <button className="rounded bg-slate-500 px-6 py-2 text-sm font-medium text-white hover:bg-slate-600">
              إلغاء
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}