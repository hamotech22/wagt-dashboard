import { slugifyOrgName } from "../../../tenant/tenant";

// بيانات تجريبية: استبدل organizationsApi بطلبات الـ API الحقيقية لاحقًا.
// ملاحظة: municipalityCode = المرجع الخارجي في منصة مدينتي (أمانة منطقة نجران = 9 حسب الدليل).
// slug = النطاق الفرعي للجهة ويظهر في الرابط بعد تسجيل الدخول، مثال: /najran/dashboard

const mockOrganizations = [
  {
    id: 1,
    name: 'أمانة منطقة نجران',
    slug: 'najran',
    code: 'ORG-001',
    municipalityCode: '9',
    email: 'info@najran.gov.sa',
    phone: '+966 500000001',
    website: 'https://najran.gov.sa',
    city: 'نجران',
    region: 'منطقة نجران',
    address: 'حي الفهد، شارع الملك عبدالعزيز',
    status: 'active',
    createdAt: '2024-01-10',
  },
  {
    id: 2,
    name: 'بلدية الرياض',
    slug: 'riyadh',
    code: 'ORG-002',
    municipalityCode: '',
    email: 'info@riyadh.gov.sa',
    phone: '+966 500000002',
    website: 'https://riyadh.gov.sa',
    city: 'الرياض',
    region: 'منطقة الرياض',
    address: 'حي الملز، شارع الأمير محمد بن عبدالعزيز',
    status: 'active',
    createdAt: '2024-02-12',
  },
  {
    id: 3,
    name: 'بلدية جدة',
    slug: 'jeddah',
    code: 'ORG-003',
    municipalityCode: '',
    email: 'info@jeddah.gov.sa',
    phone: '+966 500000003',
    website: '',
    city: 'جدة',
    region: 'منطقة مكة المكرمة',
    address: 'حي الروضة',
    status: 'active',
    createdAt: '2024-03-05',
  },
];

// بلديات فرعية (بيانات مرجعية قادمة من مدينتي – للقراءة فقط)
const mockSubMunicipalities = [
  { id: 1, organizationId: 1, code: '901', arabicName: 'بلدية شرورة', isRelatedSubMunicipality: true },
  { id: 2, organizationId: 1, code: '902', arabicName: 'بلدية يدمة', isRelatedSubMunicipality: true },
  { id: 3, organizationId: 1, code: '903', arabicName: 'بلدية بدر الجنوب', isRelatedSubMunicipality: false },
  { id: 4, organizationId: 2, code: '201', arabicName: 'بلدية العليا الفرعية', isRelatedSubMunicipality: true },
];

const mockProjects = [
  { id: 1, organizationId: 1, name: 'مشروع النخيل', code: 'PRJ-1001', contractor: 'مقاول الخليج', status: 'active' },
  { id: 2, organizationId: 1, name: 'مشروع الأفق', code: 'PRJ-1004', contractor: 'مقاول النخيل', status: 'active' },
  { id: 3, organizationId: 1, name: 'مشروع السد', code: 'PRJ-1003', contractor: 'مقاول الرواد', status: 'completed' },
  { id: 4, organizationId: 2, name: 'مشروع الروضة', code: 'PRJ-1002', contractor: 'مقاول النخيل', status: 'pending' },
];

export const statuses = {
  all: { label: 'الكل', style: 'bg-slate-100 text-slate-700' },
  active: { label: 'نشطة', style: 'bg-emerald-100 text-emerald-700' },
  inactive: { label: 'غير نشطة', style: 'bg-slate-100 text-slate-600' },
};

export const projectStatuses = {
  active: { label: 'نشط', style: 'bg-emerald-100 text-emerald-700' },
  pending: { label: 'قيد التنفيذ', style: 'bg-amber-100 text-amber-700' },
  completed: { label: 'مكتمل', style: 'bg-sky-100 text-sky-700' },
  cancelled: { label: 'ملغي', style: 'bg-red-100 text-red-700' },
};

export function listTenants() {
  return mockOrganizations.filter((org) => org.status === "active");
}

export function findTenantBySlug(slug) {
  if (!slug) return null;
  const key = String(slug).toLowerCase();
  return mockOrganizations.find((org) => org.slug?.toLowerCase() === key) || null;
}

export function resolveTenantFromLocation() {
  const first = window.location.pathname.split("/").filter(Boolean)[0];
  if (!first) return null;

  const reserved = new Set(["login", "register", "forbidden", "dashboard", "assets"]);
  if (reserved.has(first)) return null;

  const org = findTenantBySlug(first);
  if (org) {
    return { id: org.id, name: org.name, slug: org.slug, code: org.code, city: org.city };
  }

  return { slug: first, missing: true };
}

export const organizationsApi = {
  async list() {
    return mockOrganizations.map((org) => ({
      ...org,
      subMunicipalitiesCount: mockSubMunicipalities.filter((s) => s.organizationId === org.id).length,
      projectsCount: mockProjects.filter((p) => p.organizationId === org.id).length,
    }));
  },

  async get(id) {
    const orgId = Number(id);
    const org = mockOrganizations.find((item) => item.id === orgId);
    if (!org) throw new Error('الجهة غير موجودة');
    return org;
  },

  async subMunicipalities(organizationId) {
    return mockSubMunicipalities.filter((item) => item.organizationId === Number(organizationId));
  },

  async projects(organizationId) {
    return mockProjects.filter((item) => item.organizationId === Number(organizationId));
  },

  async create(data) {
    const code = data.code || `ORG-${Date.now()}`;
    const slug = data.slug?.trim() || slugifyOrgName(data.name, code);
    if (mockOrganizations.some((org) => org.slug === slug)) {
      throw new Error("النطاق الفرعي مستخدم لجهة أخرى");
    }
    const created = {
      ...data,
      id: Date.now(),
      code,
      slug,
      createdAt: new Date().toISOString().slice(0, 10),
    };
    mockOrganizations.unshift(created);
    return created;
  },

  async update(id, data) {
    const index = mockOrganizations.findIndex((item) => item.id === id);
    if (index === -1) throw new Error('الجهة غير موجودة');
    const slug = data.slug?.trim() || mockOrganizations[index].slug || slugifyOrgName(data.name, data.code);
    if (mockOrganizations.some((org) => org.slug === slug && org.id !== id)) {
      throw new Error("النطاق الفرعي مستخدم لجهة أخرى");
    }
    const updated = { ...mockOrganizations[index], ...data, slug, id };
    mockOrganizations[index] = updated;
    return updated;
  },

  async remove(id) {
    const index = mockOrganizations.findIndex((item) => item.id === id);
    if (index === -1) throw new Error('الجهة غير موجودة');
    if (mockProjects.some((p) => p.organizationId === id)) {
      throw new Error('لا يمكن حذف جهة مرتبطة بمشاريع');
    }
    mockOrganizations.splice(index, 1);
    return { id };
  },
};
