import VehicleForm from "./VehicleForm";
import { createVehicle } from "./vehiclesApi";

export default function AddVehicle() {
  return (
    <div dir="rtl" className="p-6 max-w-4xl space-y-5">
      <h1 className="text-2xl font-bold text-gray-800">إضافة مركبة جديدة</h1>
      <VehicleForm onSubmit={createVehicle} submitLabel="إضافة المركبة" />
    </div>
  );
}
