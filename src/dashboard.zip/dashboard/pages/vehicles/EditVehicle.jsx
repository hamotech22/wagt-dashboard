import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import VehicleForm from "./VehicleForm";
import { fetchVehicle, updateVehicle } from "./vehiclesApi";

export default function EditVehicle() {
  const { id } = useParams();
  const [vehicle, setVehicle] = useState(null);

  useEffect(() => {
    fetchVehicle(id).then(setVehicle);
  }, [id]);

  if (!vehicle) return <div className="p-6 text-gray-400">جارِ التحميل...</div>;

  return (
    <div dir="rtl" className="p-6 max-w-4xl space-y-5">
      <h1 className="text-2xl font-bold text-gray-800">تعديل المركبة</h1>
      <VehicleForm initialData={vehicle} onSubmit={(d) => updateVehicle(id, d)} submitLabel="حفظ التعديلات" />
    </div>
  );
}
