// ⚠️ بيانات وهمية — استبدل كل دالة بنداء api.get/post لاحقاً
// import { api } from "../../../api";
// ملاحظة: المركبات بيانات داخلية للمنصة، ومدينتي ليست مصدراً مرجعياً لها (بند 10)

let VEHICLES = [
  { id: 1, plateNumber: "1234", plateChars: "أ ب ج", type: "dump", contractorId: 1, projectId: 1,
    status: "active", source: "manual", createdAt: "2026-04-02T09:00:00", updatedAt: "2026-08-15T10:20:00" },
  { id: 2, plateNumber: "5678", plateChars: "د هـ و", type: "compactor", contractorId: 1, projectId: 1,
    status: "active", source: "import", createdAt: "2026-04-02T09:05:00", updatedAt: "2026-04-02T09:05:00" },
  { id: 3, plateNumber: "9012", plateChars: "ر س ص", type: "truck", contractorId: 2, projectId: 2,
    status: "suspended", source: "manual", createdAt: "2026-05-11T12:00:00", updatedAt: "2026-09-01T08:00:00" },
  { id: 4, plateNumber: "3456", plateChars: "ط ع ك", type: "truck", contractorId: null, projectId: null,
    status: "pending", source: "anpr", createdAt: "2026-09-19T14:32:00", updatedAt: "2026-09-19T14:32:00" },
];

const wait = (v) => new Promise((r) => setTimeout(() => r(v), 300));
const now = () => new Date().toISOString();

export const fetchVehicles = () => wait([...VEHICLES]);
export const fetchVehicle = (id) => wait(VEHICLES.find((v) => v.id === Number(id)));

export const createVehicle = (data) => {
  VEHICLES.push({ ...data, id: Date.now(), source: "manual", createdAt: now(), updatedAt: now() });
  return wait(true);
};
export const updateVehicle = (id, data) => {
  VEHICLES = VEHICLES.map((v) => (v.id === Number(id) ? { ...v, ...data, updatedAt: now() } : v));
  return wait(true);
};
export const deleteVehicle = (id) => {
  VEHICLES = VEHICLES.filter((v) => v.id !== Number(id));
  return wait(true);
};

// آخر عمليات المركبة (وهمي) — لاحقاً: GET /vehicles/:id/transactions
export const fetchVehicleTransactions = (vehicleId) =>
  wait([
    { id: 101, vehicleId: 1, date: "2026-09-19T08:10:00", site: "مردم نجران الرئيسي", waste: "منزلي", weight: 8.4, status: "synced" },
    { id: 102, vehicleId: 1, date: "2026-09-18T13:45:00", site: "مردم نجران الرئيسي", waste: "إنشائي", weight: 12.1, status: "synced" },
    { id: 103, vehicleId: 1, date: "2026-09-17T09:30:00", site: "مردم نجران الرئيسي", waste: "منزلي", weight: 7.9, status: "pending" },
  ].filter((item) => !vehicleId || item.vehicleId === Number(vehicleId)));

export const fetchVehicleLookups = () =>
  wait({
    // لا تُثبّت في الكود: تُدار كبيانات مرجعية
    types: [
      { value: "truck", label: "شاحنة" },
      { value: "dump", label: "قلاب" },
      { value: "compactor", label: "ضاغطة نفايات" },
      { value: "tanker", label: "صهريج" },
      { value: "pickup", label: "وانيت" },
    ],
    contractors: [
      { id: 1, name: "شركة النظافة المتحدة" },
      { id: 2, name: "مؤسسة الجنوب للمقاولات" },
    ],
    // المقاول قد يعمل في أكثر من مشروع (بند 7)
    projects: [
      { id: 1, name: "مشروع نظافة نجران", contractorIds: [1] },
      { id: 2, name: "مشروع نظافة شرورة", contractorIds: [2, 1] },
    ],
  });
