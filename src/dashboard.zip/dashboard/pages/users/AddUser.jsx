import UserForm from "./UserForm";
import { createUser } from "./usersApi";

export default function AddUser() {
  return (
    <div dir="rtl" className="p-6 space-y-5">
      <h1 className="text-2xl font-bold text-gray-800">إضافة مستخدم جديد</h1>
      <UserForm onSubmit={createUser} submitLabel="إضافة المستخدم" />
    </div>
  );
}
