// ⚠️ بيانات وهمية — استبدل كل دالة بنداء api.get/post لاحقاً
// import { api } from "../../../api";

/* ------------------------------------------------------------------ */
/*  كتالوجات النظام (بند 37 – 40): RBAC + Data Scope + Module Access   */
/*  لاحقاً تأتي من الـ Backend بدل ما تكون ثابتة هنا                     */
/* ------------------------------------------------------------------ */

// بند 38 — Functional Permissions
export const ACTIONS = [
  { key: "view", label: "عرض" },
  { key: "create", label: "إضافة" },
  { key: "edit", label: "تعديل" },
  { key: "delete", label: "حذف" },
  { key: "approve", label: "اعتماد" },
  { key: "export", label: "تصدير" },
  { key: "retry", label: "إعادة إرسال" },
  { key: "cancel", label: "إلغاء عملية" },
];

// الموارد التي تُطبَّق عليها الصلاحيات، مع الإجراءات المتاحة لكل مورد فقط
export const RESOURCES = [
  { key: "tenants", group: "المنصة الأساسية", label: "الجهات والبلديات", actions: ["view", "create", "edit", "delete"] },
  { key: "projects", group: "المنصة الأساسية", label: "المشاريع", actions: ["view", "create", "edit", "delete"] },
  { key: "contractors", group: "المنصة الأساسية", label: "المقاولون", actions: ["view", "create", "edit", "delete", "export"] },
  { key: "users", group: "المنصة الأساسية", label: "المستخدمون", actions: ["view", "create", "edit", "delete", "export"] },
  { key: "roles", group: "المنصة الأساسية", label: "الأدوار والصلاحيات", actions: ["view", "create", "edit", "delete"] },
  { key: "audit", group: "المنصة الأساسية", label: "سجل التدقيق", actions: ["view", "export"] },

  { key: "sites", group: "البوابات الذكية", label: "المواقع ونقاط التخلص", actions: ["view", "create", "edit", "delete"] },
  { key: "gates", group: "البوابات الذكية", label: "البوابات", actions: ["view", "create", "edit", "delete"] },
  { key: "devices", group: "البوابات الذكية", label: "الأجهزة", actions: ["view", "create", "edit", "delete"] },
  { key: "vehicles", group: "البوابات الذكية", label: "المركبات", actions: ["view", "create", "edit", "delete", "export"] },
  { key: "transactions", group: "البوابات الذكية", label: "عمليات البوابة", actions: ["view", "edit", "approve", "export", "cancel"] },

  { key: "integration", group: "التكامل مع مدينتي", label: "التكامل ومراقبته", actions: ["view", "edit", "retry", "export"] },

  { key: "reports", group: "التقارير", label: "التقارير", actions: ["view", "export"] },
];

// بند 40 — Module Access (الوحدات المستقبلية معروضة لكن غير متاحة الآن)
export const MODULES = [
  { key: "executive", label: "اللوحة التنفيذية", icon: "📊", available: true },
  { key: "smart_gates", label: "البوابات الذكية", icon: "🚧", available: true },
  { key: "madinaty", label: "التكامل مع مدينتي", icon: "🔗", available: true },
  { key: "reports", label: "التقارير والتحليلات", icon: "📈", available: true },
  { key: "fleet", label: "تتبع الأسطول", icon: "🚚", available: false },
  { key: "surveillance", label: "الرقابة الذكية", icon: "👁️", available: false },
  { key: "driver", label: "مراقبة السائقين", icon: "🧑‍✈️", available: false },
  { key: "maintenance", label: "الصيانة", icon: "🛠️", available: false },
];

// بند 39 — Data Scope
export const SCOPE_LEVELS = [
  { value: "platform", label: "المنصة", hint: "كل الجهات", source: null },
  { value: "tenant", label: "الجهة", hint: "كل بيانات الجهة", source: null },
  { value: "municipality", label: "بلدية", hint: "بلدية أو أكثر", source: "municipalities" },
  { value: "sub_municipality", label: "بلدية فرعية", hint: "بلدية فرعية أو أكثر", source: "subMunicipalities" },
  { value: "project", label: "مشروع", hint: "مشروع أو أكثر", source: "projects" },
  { value: "contractor", label: "مقاول", hint: "مقاول أو أكثر", source: "contractors" },
  { value: "site", label: "موقع", hint: "موقع أو أكثر", source: "sites" },
  { value: "gate", label: "بوابة", hint: "بوابة أو أكثر", source: "gates" },
];

/* ------------------------------------------------------------------ */
/*  بيانات وهمية                                                        */
/* ------------------------------------------------------------------ */

const allPerms = () => Object.fromEntries(RESOURCES.map((r) => [r.key, [...r.actions]]));
const viewAll = () => Object.fromEntries(RESOURCES.map((r) => [r.key, ["view"]]));

// بند 41 — الأدوار المبدئية (قابلة للتعديل ولا تُثبَّت في الكود)
let ROLES = [
  { id: 1, nameAr: "مدير النظام", description: "صلاحيات كاملة على كل شيء — دور محمي",
    isSystem: true, locked: true, permissions: allPerms() },
  { id: 2, nameAr: "مدير المنصة", description: "إدارة المنصة والجهات دون تعديل الأدوار",
    isSystem: true, locked: false, permissions: { ...allPerms(), roles: ["view"] } },
  { id: 3, nameAr: "مدير البلدية", description: "متابعة مشاريع البلدية ومقاوليها ومواقعها",
    isSystem: true, locked: false,
    permissions: { ...viewAll(), projects: ["view", "create", "edit"], contractors: ["view", "create", "edit", "export"],
      transactions: ["view", "approve", "export"], reports: ["view", "export"], users: ["view", "create", "edit"] } },
  { id: 4, nameAr: "مدير المشروع", description: "إدارة مركبات وعمليات المشروع",
    isSystem: true, locked: false,
    permissions: { ...viewAll(), vehicles: ["view", "create", "edit", "export"], transactions: ["view", "edit", "approve", "export"], reports: ["view", "export"] } },

  // ===== دور جديد: مدير المقاول (Contractor Administrator) — بند 41 =====
  { id: 9, nameAr: "مدير المقاول", description: "متابعة مركبات المقاول ومشاريعه وعملياته وتقاريره فقط",
    isSystem: true, locked: false,
    permissions: { vehicles: ["view", "create", "edit"], transactions: ["view"], reports: ["view", "export"] } },

  // ===== دور جديد: مدير الموقع (Site Manager) — بند 41 =====
  { id: 10, nameAr: "مدير الموقع", description: "إدارة بوابات وأجهزة الموقع ومتابعة عملياته",
    isSystem: true, locked: false,
    permissions: { gates: ["view", "create", "edit"], devices: ["view", "create", "edit"],
      vehicles: ["view"], transactions: ["view", "edit", "approve"], reports: ["view", "export"] } },

  { id: 5, nameAr: "مشغّل بوابة", description: "تشغيل البوابة ومتابعة العمليات اليومية",
    isSystem: true, locked: false,
    permissions: { gates: ["view"], devices: ["view"], vehicles: ["view", "create"], transactions: ["view", "edit", "cancel"] } },

  // ===== دور جديد: مستخدم مراقبة (Monitoring User) — بند 41 =====
  { id: 11, nameAr: "مستخدم مراقبة", description: "اطلاع فوري على حالة البوابات والأجهزة والعمليات دون تعديل",
    isSystem: true, locked: false,
    permissions: { gates: ["view"], devices: ["view"], vehicles: ["view"], transactions: ["view"], integration: ["view"] } },

  { id: 6, nameAr: "مستخدم تقارير", description: "عرض وتصدير التقارير فقط",
    isSystem: true, locked: false,
    permissions: { transactions: ["view"], reports: ["view", "export"] } },
  { id: 7, nameAr: "مسؤول التكامل", description: "متابعة التكامل مع مدينتي وإعادة إرسال العمليات",
    isSystem: true, locked: false,
    permissions: { transactions: ["view"], integration: ["view", "edit", "retry", "export"], reports: ["view"] } },
  { id: 8, nameAr: "مدقق", description: "اطلاع كامل بدون تعديل مع تصدير سجل التدقيق",
    isSystem: true, locked: false,
    permissions: { ...viewAll(), audit: ["view", "export"], reports: ["view", "export"] } },
];

let USERS = [
  { id: 1, fullName: "جاد المولى حمدو", username: "jad.hamdo", email: "jad@example.com", phone: "0500000001",
    roleId: 1, status: "active", mfaEnabled: true, scopeLevel: "platform", scopeIds: [],
    modules: ["executive", "smart_gates", "madinaty", "reports"], lastLogin: "2026-09-20T07:30:00", createdAt: "2026-03-01" },
  { id: 2, fullName: "محمد آل مريع", username: "m.almuraya", email: "mohammed@najran.gov", phone: "0500000002",
    roleId: 3, status: "active", mfaEnabled: true, scopeLevel: "municipality", scopeIds: [1],
    modules: ["executive", "smart_gates", "reports"], lastLogin: "2026-09-20T06:45:00", createdAt: "2026-03-05" },
  { id: 3, fullName: "سعد القحطاني", username: "s.qahtani", email: "saad@contractor.sa", phone: "0500000003",
    roleId: 4, status: "active", mfaEnabled: false, scopeLevel: "project", scopeIds: [1],
    modules: ["smart_gates", "reports"], lastLogin: "2026-09-19T14:10:00", createdAt: "2026-03-12" },
  { id: 4, fullName: "خالد اليامي", username: "k.yami", email: "khaled@najran.gov", phone: "",
    roleId: 5, status: "active", mfaEnabled: false, scopeLevel: "gate", scopeIds: [1, 2],
    modules: ["smart_gates"], lastLogin: "2026-09-20T05:58:00", createdAt: "2026-03-15" },

  // ===== مستخدم جديد: مرتبط بدور "مدير المقاول" (roleId: 9) =====
  // نطاق البيانات "contractor" مع scopeIds: [1] -> يعني محصور بـ "شركة الأمل للخدمات البيئية" (id:1 في contractors)
  { id: 5, fullName: "فهد القرني", username: "f.alqarni", email: "fahad@alamal.sa", phone: "0500000005",
    roleId: 9, status: "active", mfaEnabled: false, scopeLevel: "contractor", scopeIds: [1],
    modules: ["smart_gates", "reports"], lastLogin: "2026-09-21T09:15:00", createdAt: "2026-04-01" },

  // ===== مستخدم جديد: مرتبط بدور "مدير الموقع" (roleId: 10) =====
  // نطاق البيانات "site" مع scopeIds: [1] -> يعني محصور بـ "مردم نجران" (id:1 في sites)
  { id: 6, fullName: "عبدالله الشهري", username: "a.alshehri", email: "abdullah@najran.gov", phone: "0500000006",
    roleId: 10, status: "active", mfaEnabled: true, scopeLevel: "site", scopeIds: [1],
    modules: ["smart_gates", "reports"], lastLogin: "2026-09-21T08:40:00", createdAt: "2026-04-03" },

  // ===== مستخدم جديد: مرتبط بدور "مستخدم مراقبة" (roleId: 11) =====
  // نطاق البيانات "municipality" مع scopeIds: [1] -> يشوف كل مؤشرات البلدية بدون أي تعديل
  { id: 7, fullName: "نورة العتيبي", username: "n.alotaibi", email: "noura@najran.gov", phone: "0500000007",
    roleId: 11, status: "active", mfaEnabled: true, scopeLevel: "municipality", scopeIds: [1],
    modules: ["executive", "smart_gates", "madinaty"], lastLogin: "2026-09-21T10:02:00", createdAt: "2026-04-05" },
];

const wait = (v) => new Promise((r) => setTimeout(() => r(v), 300));
const clone = (v) => JSON.parse(JSON.stringify(v));

/* ------------------------------------------------------------------ */
/*  المستخدمون                                                          */
/* ------------------------------------------------------------------ */

export const fetchUsers = () => wait(clone(USERS));
export const fetchUser = (id) => wait(clone(USERS.find((u) => u.id === Number(id))));

// كلمة المرور لا تُحفظ ولا تُعاد من الـ API — الـ Backend هو من يعمل Hash لها
export const createUser = ({ password, ...data }) => {
  USERS.push({ ...data, id: Date.now(), lastLogin: null, createdAt: new Date().toISOString().slice(0, 10) });
  return wait(true);
};
export const updateUser = (id, { password, ...data }) => {
  USERS = USERS.map((u) => (u.id === Number(id) ? { ...u, ...data } : u));
  return wait(true);
};
export const deleteUser = (id) => {
  USERS = USERS.filter((u) => u.id !== Number(id));
  return wait(true);
};

/* ------------------------------------------------------------------ */
/*  الأدوار والصلاحيات                                                  */
/* ------------------------------------------------------------------ */

export const fetchRoles = () => wait(clone(ROLES));
export const fetchRole = (id) => wait(clone(ROLES.find((r) => r.id === Number(id))));

export const createRole = (data) => {
  const role = { isSystem: false, locked: false, permissions: {}, ...data, id: Date.now() };
  ROLES.push(role);
  return wait(clone(role));
};
export const updateRole = (id, data) => {
  ROLES = ROLES.map((r) => (r.id === Number(id) ? { ...r, ...data } : r));
  return wait(true);
};
export const deleteRole = (id) => {
  if (USERS.some((u) => u.roleId === Number(id))) {
    return Promise.reject(new Error("لا يمكن حذف دور مرتبط بمستخدمين. انقل المستخدمين لدور آخر أولاً."));
  }
  ROLES = ROLES.filter((r) => r.id !== Number(id));
  return wait(true);
};

/* ------------------------------------------------------------------ */
/*  القوائم المرجعية                                                    */
/* ------------------------------------------------------------------ */

export const fetchUserLookups = () =>
  wait({
    roles: clone(ROLES),
    municipalities: [{ id: 1, name: "أمانة منطقة نجران" }],
    subMunicipalities: [
      { id: 1, name: "بلدية نجران" },
      { id: 2, name: "بلدية شرورة" },
      { id: 3, name: "بلدية بدر الجنوب" },
    ],
    projects: [
      { id: 1, name: "مشروع نظافة نجران" },
      { id: 2, name: "مشروع مردم شرورة" },
    ],
    contractors: [
      { id: 1, name: "شركة الأمل للخدمات البيئية" },
      { id: 2, name: "مؤسسة الواحة للمقاولات" },
    ],
    sites: [
      { id: 1, name: "مردم نجران" },
      { id: 2, name: "مردم شرورة" },
    ],
    gates: [
      { id: 1, name: "بوابة الدخول الرئيسية" },
      { id: 2, name: "بوابة الخروج الرئيسية" },
      { id: 3, name: "بوابة شرورة" },
    ],
  });